public enum TypeOfSolution {
    SOLUTION_BY_FORMULAS,
    SOLUTION_BY_RUNGE
}
