public enum ReimannSumRule {
    LEFT_RULE,
    RIGHT_RULE,
    MIDPOINT_RULE,
    TRAPEZOIDAL_RULE,
    SIMPSONS_RULE
}
