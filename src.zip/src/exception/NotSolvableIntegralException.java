package exception;

public class NotSolvableIntegralException extends Exception {
    public NotSolvableIntegralException() {
        super();
    }
}
